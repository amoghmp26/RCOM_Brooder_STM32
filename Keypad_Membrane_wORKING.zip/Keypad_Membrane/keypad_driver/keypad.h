// keypad.h
#ifndef KEYPAD_H
#define KEYPAD_H

#include "stm32f1xx_hal.h" // Adjust according to your STM32 family

class Keypad {
public:
    Keypad(GPIO_TypeDef* rowPorts[3], uint16_t rowPins[3],
           GPIO_TypeDef* colPorts[4], uint16_t colPins[4]);
    char readKey();

private:
    GPIO_TypeDef* _rowPorts[3];
    uint16_t _rowPins[3];
    GPIO_TypeDef* _colPorts[4];
    uint16_t _colPins[4];
    const char _keys[3][4] = {
        {'1', '2', '3', 'A'},
        {'4', '5', '6', 'B'},
        {'7', '8', '9', 'C'}
    };
};

#endif // KEYPAD_H

// keypad.cpp
#include "keypad.h"
#include <stdint.h>

Keypad::Keypad(GPIO_TypeDef* rowPorts[3], uint16_t rowPins[3],
               GPIO_TypeDef* colPorts[4], uint16_t colPins[4]) {
    for (int i = 0; i < 3; i++) {
        _rowPorts[i] = rowPorts[i];
        _rowPins[i] = rowPins[i];
        HAL_GPIO_WritePin(_rowPorts[i], _rowPins[i], GPIO_PIN_SET);
    }
    for (int i = 0; i < 4; i++) {
        _colPorts[i] = colPorts[i];
        _colPins[i] = colPins[i];
    }
}

char Keypad::readKey() {
    for (int r = 0; r < 3; r++) {
        // Set current row LOW
        HAL_GPIO_WritePin(_rowPorts[r], _rowPins[r], GPIO_PIN_RESET);

        for (int c = 0; c < 4; c++) {
            if (HAL_GPIO_ReadPin(_colPorts[c], _colPins[c]) == GPIO_PIN_RESET) {
                // Debounce delay
                HAL_Delay(200);
                // Return the detected key
                HAL_GPIO_WritePin(_rowPorts[r], _rowPins[r], GPIO_PIN_SET);
                return _keys[r][c];
            }
        }

        // Set row back to HIGH
        HAL_GPIO_WritePin(_rowPorts[r], _rowPins[r], GPIO_PIN_SET);
    }

    return '\0'; // No key pressed
}
