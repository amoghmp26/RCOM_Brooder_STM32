#pragma once

void tm1637Init(void);
//void tm1637DisplayDecimal(int v, int displaySeparator);
void tm1637SetBrightness(char brightness);
void tm1637DisplayTempHumidity(int temp, int humidity, int displaySeparator);
