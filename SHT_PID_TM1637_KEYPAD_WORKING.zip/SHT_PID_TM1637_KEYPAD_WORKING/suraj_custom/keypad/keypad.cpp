#include "Keypad.h"

Keypad::Keypad() {
    // Constructor
}

void Keypad::init() {
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // Init rows (output)
    for (int i = 0; i < 4; ++i) {
        GPIO_InitStruct.Pin = rowPins[i];
        GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
        HAL_GPIO_Init(rowPorts[i], &GPIO_InitStruct);
        HAL_GPIO_WritePin(rowPorts[i], rowPins[i], GPIO_PIN_SET); // Idle HIGH
    }

    // Init columns (input with pull-up)
    for (int i = 0; i < 4; ++i) {
        GPIO_InitStruct.Pin = colPins[i];
        GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
        GPIO_InitStruct.Pull = GPIO_PULLUP;
        HAL_GPIO_Init(colPorts[i], &GPIO_InitStruct);
    }
}

char Keypad::getKey() {
    for (int row = 0; row < 4; row++) {
        // Drive current row LOW
        HAL_GPIO_WritePin(rowPorts[row], rowPins[row], GPIO_PIN_RESET);

        // Read all columns
        for (int col = 0; col < 4; col++) {
            if (HAL_GPIO_ReadPin(colPorts[col], colPins[col]) == GPIO_PIN_RESET) {
                HAL_Delay(20); // Simple debounce
                if (HAL_GPIO_ReadPin(colPorts[col], colPins[col]) == GPIO_PIN_RESET) {
                    // Restore row
                    HAL_GPIO_WritePin(rowPorts[row], rowPins[row], GPIO_PIN_SET);
                    return keymap[row][col];
                }
            }
        }

        // Restore row HIGH
        HAL_GPIO_WritePin(rowPorts[row], rowPins[row], GPIO_PIN_SET);
    }

    return '\0'; // No key pressed
}
