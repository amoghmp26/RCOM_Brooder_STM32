#include "sht3x_t.h"
#include "i2c.h"

sht3x_t::sht3x_t(I2C_HandleTypeDef* i2cHandle) : I2C(i2cHandle) {}

sht3x_t::~sht3x_t() {}

void sht3x_t::initialise() {
    init();
}

void sht3x_t::deinitialise() {
    deinit();
}

void sht3x_t::deepSleep() {
    uint8_t command[2] = {0xB0, 0x98};
    sendBytes(SHT30_ADDRESS, command, sizeof(command), 100);
}

uint16_t sht3x_t::readTemperature() {
    uint16_t temperature, humidity;
    if (readTemperatureAndHumidity(temperature, humidity)) {
        return temperature; // Return temperature as integer
    }
    return 0xFFFF; // Error indicator
}

uint16_t sht3x_t::readHumidity() {
    uint16_t temperature, humidity;
    if (readTemperatureAndHumidity(temperature, humidity)) {
        return humidity; // Return humidity as integer
    }
    return 0xFFFF; // Error indicator
}

bool sht3x_t::readTemperatureAndHumidity(uint16_t& temperature, uint16_t& humidity) {
    uint8_t command[2] = {0x2C, 0x06};  // Measurement command
    uint8_t receivedData[6];  // Buffer for received data

    // Send measurement command
    if (!sendBytes(SHT30_ADDRESS, command, sizeof(command), 100)) {
        return false;
    }

    // Wait for sensor to process request (min 15ms recommended)
    HAL_Delay(20);

    // Receive data
    if (!receiveBytes(SHT30_ADDRESS, receivedData, 6, 100)) {
        return false;
    }

    // Convert raw temperature data using integer math
    uint16_t rawTemp = (receivedData[0] << 8) | receivedData[1];
    temperature = ((175 * rawTemp) / 65535) - 45; // Convert to °C

    // Convert raw humidity data using integer math
    uint16_t rawHumidity = (receivedData[3] << 8) | receivedData[4];
    humidity = (100 * rawHumidity) / 65535; // Convert to %

    return true;
}
