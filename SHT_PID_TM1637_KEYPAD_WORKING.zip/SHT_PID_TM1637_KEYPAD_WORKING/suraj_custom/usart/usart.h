//
//UART_HandleTypeDef huart2;
//
//void data_send(char *data);
