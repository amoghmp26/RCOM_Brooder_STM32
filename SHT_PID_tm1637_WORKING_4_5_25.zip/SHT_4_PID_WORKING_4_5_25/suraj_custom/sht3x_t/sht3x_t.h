#ifndef SHT3X_T_H_
#define SHT3X_T_H_

#include "i2c.h"

class sht3x_t : public I2C {
public:
    // Constructor & Destructor
    sht3x_t(I2C_HandleTypeDef* i2cHandle);
    virtual ~sht3x_t();

    // Sensor Control
    void initialise();
    void deinitialise();
    void deepSleep();

    // Temperature & Humidity Functions
    uint16_t readTemperature();
    uint16_t readHumidity();
    bool readTemperatureAndHumidity(uint16_t& temperature, uint16_t& humidity);

private:
    const uint16_t SHT30_ADDRESS = (0x44 << 1); // Shifted for 8-bit addressing
};

#endif /* SHT3X_T_H_ */
