//#include "usart.h"
//#include "includes.h"
//#include "stm32f4xx_hal_uart.h"
//
//
//
//void data_send(char *data) {
//    HAL_UART_Transmit(&huart2, (uint8_t *)data, strlen(data), HAL_MAX_DELAY);
//    HAL_Delay(1000);
//}
