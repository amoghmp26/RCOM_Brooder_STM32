#ifndef KEYPAD_H
#define KEYPAD_H

#include "main.h"

class Keypad {
public:
    Keypad();
    void init();
    char getKey();  // Returns the pressed key or '\0' if none

private:
    GPIO_TypeDef* rowPorts[4] = {GPIOA, GPIOA, GPIOA, GPIOB};
    uint16_t rowPins[4]       = {GPIO_PIN_0, GPIO_PIN_1, GPIO_PIN_4, GPIO_PIN_4}; // Last one PB4

    GPIO_TypeDef* colPorts[4] = {GPIOB, GPIOA, GPIOA, GPIOB};
    uint16_t colPins[4]       = {GPIO_PIN_0, GPIO_PIN_8, GPIO_PIN_9, GPIO_PIN_10};

    const char keymap[4][4] = {
        {'1', '2', '3', 'A'},
        {'4', '5', '6', 'B'},
        {'7', '8', '9', 'C'},
        {'*', '0', '#', 'D'}
    };
};

#endif
