#include "gpio_driver.h"

// Constructor
GPIO_Driver::GPIO_Driver(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin)
    : gpioPort(GPIOx), gpioPin(GPIO_Pin) {}

// Initialize GPIO
void GPIO_Driver::init() {
    __HAL_RCC_GPIOA_CLK_ENABLE();  // Enable clock for GPIOA (Change as needed)

    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = gpioPin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;

    HAL_GPIO_Init(gpioPort, &GPIO_InitStruct);
}

// Turn ON LED
void GPIO_Driver::turnOn() {
    HAL_GPIO_WritePin(gpioPort, gpioPin, GPIO_PIN_SET);
}

// Turn OFF LED
void GPIO_Driver::turnOff() {
    HAL_GPIO_WritePin(gpioPort, gpioPin, GPIO_PIN_RESET);
}

// Toggle LED
void GPIO_Driver::toggle() {
    HAL_GPIO_TogglePin(gpioPort, gpioPin);
}

bool GPIO_Driver::readGpio() {
   bool res  = (HAL_GPIO_ReadPin(gpioPort, gpioPin)== GPIO_PIN_SET);
}

