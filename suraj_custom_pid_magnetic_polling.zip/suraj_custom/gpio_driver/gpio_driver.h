#ifndef GPIO_DRIVER_H_
#define GPIO_DRIVER_H_

#include "stm32f4xx_hal.h"  // Change according to your STM32 series

class GPIO_Driver {
public:
    // Constructor
    GPIO_Driver(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);

    // Initialize GPIO
    void init();

    // Control GPIO
    void turnOn();
    void turnOff();
    void toggle();
    bool readGpio();

private:
    GPIO_TypeDef* gpioPort;
    uint16_t gpioPin;
};

#endif /* GPIO_DRIVER_H_ */
