#include "i2c.h"
#include <stdio.h>
#include <cstring>  // For C++ (preferred)
#include <string.h> // For C-style compatibility


// Constructor: Initialize I2C handle
I2C::I2C(I2C_HandleTypeDef* i2cHandle) : hi2c1(i2cHandle) {}

// Destructor
I2C::~I2C() {}

// Initialize I2C
void I2C::init() {
    HAL_I2C_Init(hi2c1);
}

// Deinitialize I2C
void I2C::deinit() {
    HAL_I2C_DeInit(hi2c1);
}

// Send data over I2C
bool I2C::sendBytes(uint16_t devAddress, uint8_t* data, uint16_t size, uint32_t timeout) {
    return (HAL_I2C_Master_Transmit(hi2c1, devAddress, data, size, timeout) == HAL_OK);
}

// Receive data over I2C
bool I2C::receiveBytes(uint16_t devAddress, uint8_t* data, uint16_t size, uint32_t timeout) {
    return (HAL_I2C_Master_Receive(hi2c1, devAddress, data, size, timeout) == HAL_OK);
}

// Send & Receive in one function
bool I2C::transfer(uint16_t devAddress, uint8_t* txData, uint16_t txSize, uint8_t* rxData, uint16_t rxSize, uint32_t timeout) {
    if (txSize > 0) {
        if (!sendBytes(devAddress, txData, txSize, timeout)) return false;
    }

    HAL_Delay(20);  // Wait for response

    if (rxSize > 0) {
        if (!receiveBytes(devAddress, rxData, rxSize, timeout)) return false;
    }

    return true;
}

// Memory Read (16-bit address)
bool I2C::memoryRead(uint16_t chipAddress, uint8_t* readValues, uint16_t dataSize, uint16_t address, uint32_t timeout) {
    uint8_t addrBytes[2] = {static_cast<uint8_t>(address >> 8), static_cast<uint8_t>(address & 0xFF)};
    return transfer(chipAddress, addrBytes, 2, readValues, dataSize, timeout);
}

// Memory Write (16-bit address)
bool I2C::memoryWrite(uint16_t chipAddress, uint8_t* writeValues, uint16_t dataSize, uint16_t address, uint32_t timeout) {
    uint8_t buffer[2 + dataSize];
    buffer[0] = static_cast<uint8_t>(address >> 8);
    buffer[1] = static_cast<uint8_t>(address & 0xFF);
    memcpy(&buffer[2], writeValues, dataSize);

    return sendBytes(chipAddress, buffer, dataSize + 2, timeout);
}

// Overloaded Memory Read (Custom address size)
bool I2C::memoryRead(uint16_t chipAddress, uint8_t* readValues, uint16_t dataSize, uint16_t addressSize, uint16_t address, uint32_t timeout) {
    uint8_t addrBytes[2];
    addrBytes[0] = static_cast<uint8_t>(address >> 8);
    addrBytes[1] = static_cast<uint8_t>(address & 0xFF);

    return transfer(chipAddress, addrBytes, addressSize, readValues, dataSize, timeout);
}

// Overloaded Memory Write (Custom address size)
bool I2C::memoryWrite(uint16_t chipAddress, uint8_t* writeValues, uint16_t dataSize, uint16_t addressSize, uint16_t address, uint32_t timeout) {
    uint8_t buffer[addressSize + dataSize];

    if (addressSize == 2) {
        buffer[0] = static_cast<uint8_t>(address >> 8);
        buffer[1] = static_cast<uint8_t>(address & 0xFF);
    } else {
        buffer[0] = static_cast<uint8_t>(address);
    }

    memcpy(&buffer[addressSize], writeValues, dataSize);

    return sendBytes(chipAddress, buffer, dataSize + addressSize, timeout);
}

// Scan I2C bus and return number of detected devices
uint8_t I2C::scanBus() {
    uint8_t foundDevices = 0;

    for (uint8_t address = 1; address < 127; address++) {
        if (HAL_I2C_IsDeviceReady(hi2c1, (address << 1), 3, 100) == HAL_OK) {
            printf("Device found at 0x%X\n", address);
            foundDevices++;
        }
    }

    return foundDevices;
}
