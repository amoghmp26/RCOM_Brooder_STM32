#ifndef I2C_H_
#define I2C_H_

#include "stm32f4xx_hal.h"

class I2C {
public:
    // Constructor & Destructor
    I2C(I2C_HandleTypeDef* i2cHandle);
    virtual ~I2C();

    // Initialization & Deinitialization
    void init();
    void deinit();

    // Basic I2C Communication
    bool sendBytes(uint16_t devAddress, uint8_t* data, uint16_t size, uint32_t timeout);
    bool receiveBytes(uint16_t devAddress, uint8_t* data, uint16_t size, uint32_t timeout);
    bool transfer(uint16_t devAddress, uint8_t* txData, uint16_t txSize, uint8_t* rxData, uint16_t rxSize, uint32_t timeout);

    // Memory Read/Write
    bool memoryRead(uint16_t chipAddress, uint8_t* readValues, uint16_t dataSize, uint16_t address, uint32_t timeout);
    bool memoryWrite(uint16_t chipAddress, uint8_t* writeValues, uint16_t dataSize, uint16_t address, uint32_t timeout);

    // Overloaded functions for different address sizes
    bool memoryRead(uint16_t chipAddress, uint8_t* readValues, uint16_t dataSize, uint16_t addressSize, uint16_t address, uint32_t timeout);
    bool memoryWrite(uint16_t chipAddress, uint8_t* writeValues, uint16_t dataSize, uint16_t addressSize, uint16_t address, uint32_t timeout);

    // I2C Bus Scanning
    uint8_t scanBus();

private:
    I2C_HandleTypeDef* hi2c1;  // Handle for I2C peripheral
};

#endif /* I2C_H_ */
